export const proxy = "https://sub.aqaarfb.com";
