import axios from "axios";
axios.defaults.baseURL = "https://subb.aqaarfb.com";
export default axios;
