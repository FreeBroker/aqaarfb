export const defColor = "#B79763";
